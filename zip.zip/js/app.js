// ============================================================================
// MAIN APPLICATION LOGIC
// ============================================================================
// This script handles all frontend interactions for the attendance system.
// It uses a simple routing mechanism based on the body ID to run page-specific code.

document.addEventListener('DOMContentLoaded', () => {
    const bodyId = document.body.id;

    switch (bodyId) {
        case 'login-page':
            initLoginPage();
            break;
        case 'teacher-page':
            initTeacherPage();
            break;
        case 'students-admin-page':
            initStudentsAdminPage();
            break;
        case 'teachers-admin-page':
            initTeachersAdminPage();
            break;
    }
});

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Shows a toast notification message.
 * @param {string} message The message to display.
 * @param {string} type 'success' or 'error'.
 */
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    
    if (!toast || !toastMessage) return;

    toastMessage.textContent = message;
    toast.className = toast.className.replace(/bg-\w+-\d+/, ''); // remove old color
    if (type === 'success') {
        toast.classList.add('bg-green-500');
    } else {
        toast.classList.add('bg-red-500');
    }

    toast.classList.remove('opacity-0');
    setTimeout(() => {
        toast.classList.add('opacity-0');
    }, 3000);
}

/**
 * Generic fetch wrapper for GET requests.
 * @param {string} url The URL to fetch data from.
 * @returns {Promise<any>} The JSON response.
 */
async function fetchData(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Fetch error:', error);
        showToast('فشل في جلب البيانات', 'error');
        throw error;
    }
}

/**
 * Generic fetch wrapper for POST requests.
 * @param {string} url The URL to post data to.
 * @param {object} data The data to send in the request body.
 * @returns {Promise<any>} The JSON response.
 */
async function postData(url, data) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Post error:', error);
        showToast('فشل في إرسال البيانات', 'error');
        throw error;
    }
}

// ============================================================================
// LOGIN PAGE
// ============================================================================

function initLoginPage() {
    const loginForm = document.getElementById('login-form');
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const teacherName = document.getElementById('teacher-name').value;
        if (teacherName.trim()) {
            localStorage.setItem('teacherName', teacherName.trim());
            window.location.href = 'teacher.html';
        }
    });
}

// ============================================================================
// TEACHER ATTENDANCE PAGE
// ============================================================================

function initTeacherPage() {
    const teacherName = localStorage.getItem('teacherName');
    if (!teacherName) {
        window.location.href = 'index.html';
        return;
    }

    document.getElementById('teacher-display-name').textContent = teacherName;

    const classTabSelect = document.getElementById('class-tab');
    const studentListContainer = document.getElementById('student-list-container');
    const sendButton = document.getElementById('send-attendance-button');
    const loader = document.getElementById('loader');
    const emptyState = document.getElementById('empty-state');
    
    // Load class tabs into dropdown
    async function loadClassTabs() {
        try {
            const classes = await fetchData(WEBHOOK_URLS.GET_CLASSES);
            classTabSelect.innerHTML = '<option value="">-- اختر القسم --</option>';
            classes.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls;
                option.textContent = cls;
                classTabSelect.appendChild(option);
            });
        } catch (error) {
            classTabSelect.innerHTML = '<option>فشل تحميل الأقسام</option>';
        }
    }

    // Load students for the selected class
    async function loadStudents() {
        const selectedClass = classTabSelect.value;
        studentListContainer.innerHTML = '';
        sendButton.disabled = true;

        if (!selectedClass) {
            emptyState.style.display = 'block';
            loader.style.display = 'none';
            return;
        }
        
        emptyState.style.display = 'none';
        loader.style.display = 'block';

        try {
            const students = await fetchData(`${WEBHOOK_URLS.GET_STUDENTS_BY_CLASS}?classTab=${encodeURIComponent(selectedClass)}`);
            renderStudentTable(students);
            sendButton.disabled = students.length === 0;
        } catch (error) {
            studentListContainer.innerHTML = '<p class="text-center text-red-500 p-4">حدث خطأ أثناء تحميل الطلاب.</p>';
        } finally {
            loader.style.display = 'none';
        }
    }

    function renderStudentTable(students) {
        if (students.length === 0) {
            studentListContainer.innerHTML = '<p class="text-center text-gray-500 p-8">لا يوجد طلاب في هذا القسم.</p>';
            return;
        }

        const table = document.createElement('table');
        table.className = 'min-w-full divide-y divide-gray-200';
        table.innerHTML = `
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الرقم</th>
                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الاسم واللقب</th>
                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">رقم الهاتف</th>
                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">تسجيل غياب</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                ${students.map((student, index) => `
                    <tr data-student-id="${student.id}" data-student-name="${student.name}">
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${index + 1}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${student.name}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${student.phone || 'غير متوفر'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-center">
                            <input type="checkbox" class="h-5 w-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 absence-checkbox">
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        `;
        studentListContainer.appendChild(table);
    }
    
    // Send attendance data
    async function sendAttendance() {
        const studentRows = studentListContainer.querySelectorAll('tbody tr');
        const studentsPayload = Array.from(studentRows).map(row => {
            const name = row.dataset.studentName;
            const isAbsent = row.querySelector('.absence-checkbox').checked;
            return { name, status: isAbsent ? 'absent' : 'present' };
        });

        const payload = {
            teacher: localStorage.getItem('teacherName'),
            classTab: document.getElementById('class-tab').value,
            session: document.getElementById('session').value,
            students: studentsPayload,
            timestamp: new Date().toISOString()
        };
        
        sendButton.disabled = true;
        sendButton.textContent = 'جاري الإرسال...';
        
        try {
            await postData(WEBHOOK_URLS.POST_ATTENDANCE, payload);
            showToast('تم إرسال الحضور بنجاح', 'success');
        } catch (error) {
            showToast('فشل إرسال الحضور', 'error');
        } finally {
            sendButton.disabled = false;
            sendButton.textContent = 'إرسال الحضور';
        }
    }

    // Event Listeners
    document.getElementById('logout-button').addEventListener('click', () => {
        localStorage.removeItem('teacherName');
        window.location.href = 'index.html';
    });

    classTabSelect.addEventListener('change', loadStudents);
    sendButton.addEventListener('click', sendAttendance);

    // Initial load
    loadClassTabs();
}

// ============================================================================
// ADMIN: STUDENTS PAGE
// ============================================================================

function initStudentsAdminPage() {
    const loader = document.getElementById('admin-loader');
    const container = document.getElementById('admin-student-list-container');
    const modal = document.getElementById('student-modal');
    const form = document.getElementById('student-form');
    
    let allClassTabs = [];

    async function loadAllStudents() {
        loader.style.display = 'block';
        container.innerHTML = '';
        try {
            const students = await fetchData(WEBHOOK_URLS.GET_ALL_STUDENTS);
            renderAdminStudentTable(students);
        } catch (error) {
            container.innerHTML = '<p class="text-center text-red-500 p-4">حدث خطأ أثناء تحميل الطلاب.</p>';
        } finally {
            loader.style.display = 'none';
        }
    }
    
    async function populateClassDropdown(selectElement) {
         try {
            allClassTabs = await fetchData(WEBHOOK_URLS.GET_CLASSES);
            selectElement.innerHTML = '';
            allClassTabs.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls;
                option.textContent = cls;
                selectElement.appendChild(option);
            });
        } catch (error) {
            console.error("Failed to load classes for dropdown", error);
        }
    }

    function renderAdminStudentTable(students) {
        const table = document.createElement('table');
        table.className = 'min-w-full divide-y divide-gray-200';
        table.innerHTML = `
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الرقم</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الاسم</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الهاتف</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">القسم</th>
                    <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">إجراءات</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                ${students.map((student, index) => `
                    <tr data-student-id="${student.id}">
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${index + 1}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${student.name}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${student.phone || '-'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${student.class}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium space-x-2 space-x-reverse">
                            <button class="text-indigo-600 hover:text-indigo-900 edit-student">تعديل</button>
                            <button class="text-red-600 hover:text-red-900 delete-student">حذف</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        `;
        container.innerHTML = '';
        container.appendChild(table);
    }
    
    function openModal(student = null, rowIndex = -1) {
        form.reset();
        document.getElementById('modal-title').textContent = student ? 'تعديل بيانات طالب' : 'إضافة طالب جديد';
        document.getElementById('student-id').value = student ? student.id : '';
        document.getElementById('student-row-index').value = rowIndex;
        if(student) {
            document.getElementById('student-name').value = student.name || '';
            document.getElementById('student-phone').value = student.phone || '';
            document.getElementById('student-class').value = student.class || '';
        }
        modal.style.display = 'block';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const studentId = document.getElementById('student-id').value;
        const payload = {
            id: studentId,
            name: document.getElementById('student-name').value,
            phone: document.getElementById('student-phone').value,
            class: document.getElementById('student-class').value,
        };

        const url = studentId ? WEBHOOK_URLS.UPDATE_STUDENT : WEBHOOK_URLS.ADD_STUDENT;
        try {
            await postData(url, payload);
            showToast(studentId ? 'تم تحديث الطالب بنجاح' : 'تم إضافة الطالب بنجاح', 'success');
            loadAllStudents(); // Refresh the list
            closeModal();
        } catch (error) {
            showToast('حدث خطأ', 'error');
        }
    });
    
    container.addEventListener('click', async (e) => {
        const target = e.target;
        const row = target.closest('tr');
        if (!row) return;

        const studentId = row.dataset.studentId;

        if (target.classList.contains('edit-student')) {
            const student = {
                id: studentId,
                name: row.cells[1].textContent,
                phone: row.cells[2].textContent,
                class: row.cells[3].textContent,
            };
            openModal(student, row.rowIndex);
        }

        if (target.classList.contains('delete-student')) {
            if (confirm('هل أنت متأكد من حذف هذا الطالب؟')) {
                try {
                    await postData(WEBHOOK_URLS.DELETE_STUDENT, { id: studentId });
                    showToast('تم حذف الطالب بنجاح', 'success');
                    row.remove();
                } catch (error) {
                     showToast('فشل حذف الطالب', 'error');
                }
            }
        }
    });

    document.getElementById('add-student-button').addEventListener('click', () => openModal());
    document.getElementById('cancel-student-button').addEventListener('click', closeModal);

    // Initial Load
    populateClassDropdown(document.getElementById('student-class'));
    loadAllStudents();
}


// ============================================================================
// ADMIN: TEACHERS PAGE
// ============================================================================

function initTeachersAdminPage() {
    const loader = document.getElementById('admin-loader');
    const teacherList = document.getElementById('teacher-list');
    const addTeacherForm = document.getElementById('add-teacher-form');

    async function loadTeachers() {
        loader.style.display = 'block';
        teacherList.innerHTML = '';
        try {
            const teachers = await fetchData(WEBHOOK_URLS.GET_TEACHERS);
            renderTeacherList(teachers);
        } catch (error) {
            teacherList.innerHTML = '<li><p class="text-center text-red-500 p-4">فشل في تحميل المعلمين.</p></li>';
        } finally {
            loader.style.display = 'none';
        }
    }
    
    function renderTeacherList(teachers) {
        teacherList.innerHTML = teachers.map(teacher => `
            <li class="px-6 py-4 flex items-center justify-between" data-teacher-id="${teacher.id}">
                <p class="text-sm font-medium text-gray-900">${teacher.name}</p>
                <button class="text-sm text-red-600 hover:text-red-900 delete-teacher">حذف</button>
            </li>
        `).join('');
    }

    addTeacherForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newTeacherNameInput = document.getElementById('new-teacher-name');
        const name = newTeacherNameInput.value.trim();
        if (name) {
            try {
                await postData(WEBHOOK_URLS.ADD_TEACHER, { name });
                showToast('تم إضافة المعلم بنجاح', 'success');
                newTeacherNameInput.value = '';
                loadTeachers(); // Refresh list
            } catch (error) {
                showToast('فشل في إضافة المعلم', 'error');
            }
        }
    });

    teacherList.addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-teacher')) {
            if (confirm('هل أنت متأكد من حذف هذا المعلم؟')) {
                const listItem = e.target.closest('li');
                const teacherId = listItem.dataset.teacherId;
                try {
                    await postData(WEBHOOK_URLS.DELETE_TEACHER, { id: teacherId });
                    showToast('تم حذف المعلم بنجاح', 'success');
                    listItem.remove();
                } catch (error) {
                    showToast('فشل حذف المعلم', 'error');
                }
            }
        }
    });

    // Initial Load
    loadTeachers();
}