// ============================================================================
// CONFIGURATION FILE
// ============================================================================
// This file centralizes all the webhook URLs for the n8n automation.
// Replace the placeholder URLs with your actual n8n webhook URLs.

const WEBHOOK_URLS = {
    // Fetches the list of available classes/tabs for the dropdown.
    // Expected response: ["المستوى الأول أ", "المستوى الأول ب", ...]
    GET_CLASSES: 'https://n8n.example.com/webhook/get-classes',

    // Fetches students for a specific class. Appends `?classTab=CLASS_NAME`
    // Expected response: [{ "id": 1, "name": "...", "phone": "..." }, ...]
    GET_STUDENTS_BY_CLASS: 'https://n8n.example.com/webhook/get-students-by-class',

    // Submits the attendance data.
    // Method: POST, Body: JSON payload
    POST_ATTENDANCE: 'https://n8n.example.com/webhook/post-attendance',

    // --- Admin: Students ---
    // Fetches all students for the admin management page.
    // Expected response: [{ "id": 1, "name": "...", "phone": "...", "class": "..." }, ...]
    GET_ALL_STUDENTS: 'https://n8n.example.com/webhook/get-all-students',

    // Adds a new student.
    // Method: POST, Body: { name, phone, class }
    ADD_STUDENT: 'https://n8n.example.com/webhook/add-student',

    // Updates an existing student's data.
    // Method: POST, Body: { id, name, phone, class }
    UPDATE_STUDENT: 'https://n8n.example.com/webhook/update-student',

    // Deletes a student.
    // Method: POST, Body: { id }
    DELETE_STUDENT: 'https://n8n.example.com/webhook/delete-student',

    // --- Admin: Teachers ---
    // Fetches all teachers for the admin management page.
    // Expected response: [{ "id": 1, "name": "..." }, ...]
    GET_TEACHERS: 'https://n8n.example.com/webhook/get-teachers',
    
    // Adds a new teacher.
    // Method: POST, Body: { name }
    ADD_TEACHER: 'https://n8n.example.com/webhook/add-teacher',
    
    // Deletes a teacher.
    // Method: POST, Body: { id }
    DELETE_TEACHER: 'https://n8n.example.com/webhook/delete-teacher',
};
